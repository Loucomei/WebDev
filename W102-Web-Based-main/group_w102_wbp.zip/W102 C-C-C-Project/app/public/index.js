const titi= "Climate change has arrived. The world is now experiencing the dangerous impacts of a rapidly heating climate. See the latest resarch and news about climate change:";
    
document.getElementById("title").innerHTML=titi;

var swiper = new Swiper(".mySwiper", {
    slidesPerView: 3,
    spaceBetween: 30,
    slidesPerGroup: 3,
    loop: true,
    loopFillGroupWithBlank: true,
    pagination: {
      el: ".swiper-pagination",
      clickable: true,
    },
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
  });