/* second callback to handel text returned */
function onTextReady(text){
    console.log(text);
    
    txt.innerText = text;
}

const txt =document.querySelector("#post-response");

/* first callback function */
function onResponse(response){
    return response.text();
}

/* Style Text in JSON */
Object.assign((txt).style, {
"color":"red", 
"text-align": "center"
})
    

    


/* the data we want to send to node */
const message = {
    name:'A.Reed',
    email: 'zcz21jvu@uea.ac.uk'
};


/* convert JS object to JSON */
const serializedMessage = JSON.stringify(message);

/* the request data */
const fetchOptions ={
    method: 'POST',
    headers:{
        'Accept': 'application/json',
        'Content-Type': 'application/json'
    },
    body: serializedMessage
}


fetch('http://localhost:3000/hello',fetchOptions)
.then(onResponse)
.then(onTextReady);