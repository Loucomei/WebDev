/* Grab the form element using document.querySelector method */
const capture = document.querySelector("#submit");

/* listen to submit event */
capture.addEventListener("click", processSubmit);

/* second callback to handel text returned */
function onTextReady(text) {
    console.log(text);
    const p = document.querySelector("#complete");
    p.textContent = text;
}

/* first callback function */
function onResponse(response) {
    return response.text();
}


/* process on submit event */
function processSubmit(e) {
    e.preventDefault();
    
    const retVal = {
    forename: document.querySelector("#forename").value,
    surname: document.querySelector("#surname").value,
    email: document.querySelector("#email").value,
    age: document.querySelector("#age").value,
    message: document.querySelector("#message").value
    };
    

    /* convert JS object to JSON */
    const serializedMessage = JSON.stringify(retVal);

    /* the request data */
    const fetchOptions = {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: serializedMessage
    };
    fetch('http://localhost:3000/contact', fetchOptions)
        .then(onResponse)
        .then(onTextReady);
};


console.log("test")





