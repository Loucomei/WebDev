const express = require('express')
const app = express();
const port = 3000;

const bodyParser = require('body-parser');
const jsonParser = bodyParser.json();

app.use(express.static('public'));

app.get('/', (req, res) => {
    //res.send('Web Programming is fun!... ')
    //send the static file
    res.sendFile('index.html'),(err) => {
        if (err){
            console.log(err);
        }
    }

});


/* POST request for Form response and submit*/
app.post('/contact', jsonParser, (req,res) => {
    const body = req.body;
    const forename = body.forename;
    const surname = body.surname;
    const email = body.email;
    const age = body.age;
    const message = body.message;
    res.send(`Thank you for your submission- name = ${forename +" "+ surname}. Details are as follows,  
     email = ${email} , message = ${message}, age = ${age}` )
    
});


/* GET request */
app.get('/contact',(req,res) => {
    res.send('GET: Hello!');
});

/* GET request with paramenter */
app.get('/hello/:name',(req,res) => {
    const routeParams = req.params;
    const name = routeParams.name;
    res.send('GET: Hello; ' + name);
});

/* POST request with paramenter */
app.post('/hello', jsonParser, (req,res) => {
    const body = req.body;
    const forename = body.name;
    const surname = body.surname;
    const email = body.email;
    const age = body.age;
    const message = body.message;
    res.send('POST: Name; ' + forename + " " + surname + ', Email:' + email + ', Age:' + age + ', Message:' + message) ;
});

/* POST request with paramenter */
app.listen(port, () => {
    console.log(`this is my first app listing on port ${port}!`)
});


/*Code explained: The function uses body-parser package to parse the values
from the request body. The function relay the values back to the client/browser.
We can’t use a browser to test the POST request because browsers are sending
GET requests by default. For this lab exercise, we will write a client code to test
this request.*/

